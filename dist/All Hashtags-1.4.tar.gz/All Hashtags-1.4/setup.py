from setuptools import setup

setup(
    name="All Hashtags",
    version="1.4", 
    description="",
    author="In Dev",
    packages=["hashtags"],
    install_requires=[]
)